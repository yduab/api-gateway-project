package com.yididiya.gateway;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;

@Component
public class PaymentProxyFilter extends OncePerRequestFilter {

    private static final String PAYMENT_SERVICE_URL = "http://payment-service:8083";

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String path = request.getRequestURI();

        if (!path.startsWith("/api/payments") && !path.startsWith("/api/checkout")) {
            filterChain.doFilter(request, response);
            return;
        }

        byte[] body = request.getInputStream().readAllBytes();
        String method = request.getMethod();
        String targetUrl = PAYMENT_SERVICE_URL + path;

        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(targetUrl).openConnection();
            conn.setRequestMethod(method);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            Collections.list(request.getHeaderNames()).forEach(name -> {
                if (!name.equalsIgnoreCase("content-length")) {
                    conn.setRequestProperty(name, request.getHeader(name));
                }
            });

            if (body.length > 0) {
                conn.setDoOutput(true);
                conn.getOutputStream().write(body);
            }

            conn.connect();
            int status = conn.getResponseCode();
            InputStream is = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
            String responseBody = is == null ? "" : new String(is.readAllBytes());

            response.setStatus(status);
            response.setContentType("application/json");
            response.getWriter().write(responseBody);
            response.flushBuffer();

        } catch (Exception e) {
            System.out.println(">>> Payment service unreachable: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
            response.setContentType("application/json");
            response.getWriter().write("{\"error\": \"Payment service unavailable\"}");
            response.flushBuffer();
        }
    }
}