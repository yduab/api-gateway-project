package com.yididiya.payment_service;

public class CheckoutRequest {
    public Long productId;
    public int quantity;
}