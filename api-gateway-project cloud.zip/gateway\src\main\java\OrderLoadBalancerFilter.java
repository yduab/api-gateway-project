package com.yididiya.gateway;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class OrderLoadBalancerFilter extends OncePerRequestFilter {

    private final AtomicInteger counter = new AtomicInteger(0);

    private final String[] instances = {
        "http://order-service-1:8082",
        "http://order-service-2:8082",
        "http://order-service-3:8082"
    };

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String path = request.getRequestURI();

        if (!path.startsWith("/api/orders") && !path.startsWith("/api/products")) {
            filterChain.doFilter(request, response);
            return;
        }

        byte[] body = request.getInputStream().readAllBytes();
        String method = request.getMethod();
        int startIndex = counter.getAndIncrement() % instances.length;

        for (int i = 0; i < instances.length; i++) {
            int index = (startIndex + i) % instances.length;
            String targetUrl = instances[index] + path;

            // Exponential backoff — 3 attempts per instance
            int maxRetries = 3;
            for (int attempt = 0; attempt < maxRetries; attempt++) {
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(targetUrl).openConnection();
                    conn.setRequestMethod(method);
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);

                    Collections.list(request.getHeaderNames()).forEach(name -> {
                        if (!name.equalsIgnoreCase("content-length")) {
                            conn.setRequestProperty(name, request.getHeader(name));
                        }
                    });

                    if (body.length > 0) {
                        conn.setDoOutput(true);
                        conn.getOutputStream().write(body);
                    }

                    conn.connect();
                    int status = conn.getResponseCode();
                    InputStream is = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
                    String responseBody = is == null ? "" : new String(is.readAllBytes());

                    response.setStatus(status);
                    response.setContentType("application/json");
                    response.getWriter().write(responseBody);
                    response.flushBuffer();
                    return; // success

                } catch (Exception e) {
                    // Exponential backoff: 100ms, 200ms, 300ms
                    long backoff = (attempt + 1) * 100L;
                    System.out.println(">>> Instance " + instances[index] + " attempt " + (attempt + 1) + " failed, waiting " + backoff + "ms");
                    try { Thread.sleep(backoff); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
                }
            }
            System.out.println(">>> Instance " + instances[index] + " all retries failed, trying next instance");
        }

        // All instances failed
        response.setStatus(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
        response.setContentType("application/json");
        response.getWriter().write("{\"error\": \"All order instances unavailable\"}");
        response.flushBuffer();
    }
}