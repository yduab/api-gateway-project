package com.yididiya.gateway;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

@Configuration
public class GatewayConfig {

    @Bean
    public FilterRegistrationBean<OrderLoadBalancerFilter> orderFilterRegistration(
            OrderLoadBalancerFilter filter) {
        FilterRegistrationBean<OrderLoadBalancerFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(filter);
        registration.addUrlPatterns("/api/orders/*", "/api/products/*");
        registration.setOrder(Ordered.LOWEST_PRECEDENCE);
        return registration;
    }

    @Bean
    public FilterRegistrationBean<PaymentProxyFilter> paymentFilterRegistration(
            PaymentProxyFilter filter) {
        FilterRegistrationBean<PaymentProxyFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(filter);
        registration.addUrlPatterns("/api/payments/*", "/api/checkout/*");
        registration.setOrder(Ordered.LOWEST_PRECEDENCE);
        return registration;
    }
}