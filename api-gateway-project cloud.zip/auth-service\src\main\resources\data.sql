INSERT INTO users (username, password)
SELECT 'user', 'pass'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'user');