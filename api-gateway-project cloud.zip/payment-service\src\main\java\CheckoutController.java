package com.yididiya.payment_service;

import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import java.util.Map;

@RestController
public class CheckoutController {

    private final PaymentRepository paymentRepository;
    private final RestTemplate restTemplate;

    private static final String ORDER_SERVICE_URL = "http://order-service-1:8082";

    public CheckoutController(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
        this.restTemplate = new RestTemplate(new HttpComponentsClientHttpRequestFactory());
    }

    @PostMapping("/api/checkout")
    public ResponseEntity<?> checkout(@RequestBody CheckoutRequest req) {

        // 1. Fetch product from order-service
        ResponseEntity<Map> productResponse;
        try {
            productResponse = restTemplate.getForEntity(
                ORDER_SERVICE_URL + "/api/products/" + req.productId, Map.class);
        } catch (Exception e) {
            return ResponseEntity.status(404).body(Map.of("error", "Product not found"));
        }

        Map product = productResponse.getBody();
        int available = (Integer) product.get("quantity");

        // 2. Check stock
        if (available < req.quantity) {
            return ResponseEntity.status(400).body(
                Map.of("error", "Insufficient stock", "available", available));
        }

        // 3. Deduct stock
        int newQty = available - req.quantity;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        restTemplate.exchange(
            ORDER_SERVICE_URL + "/api/products/" + req.productId + "/quantity",
            HttpMethod.PATCH,
            new HttpEntity<>(Map.of("quantity", newQty), headers),
            Map.class
        );

        // 4. Create payment record
        Payment payment = new Payment();
        payment.setOrderId(String.valueOf(req.productId));
        payment.setAmount(req.quantity * 1.0);
        payment.setStatus("PAID");
        paymentRepository.save(payment);

        return ResponseEntity.ok(Map.of(
            "status", "CHECKOUT_SUCCESS",
            "productId", req.productId,
            "quantityPurchased", req.quantity,
            "remainingStock", newQty
        ));
    }
}