package com.yididiya.auth_service;

public class LoginResponse {
    public String token;

    public LoginResponse(String token) {
        this.token = token;
    }
}