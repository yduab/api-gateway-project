package com.yididiya.auth_service;

public class LoginRequest {
    public String username;
    public String password;
}