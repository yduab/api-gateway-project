package com.yididiya.payment_service;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
public class PaymentController {

    private final PaymentRepository paymentRepository;

    public PaymentController(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    @GetMapping("/api/payments/ping")
    public String ping() { return "PAYMENTS OK"; }

    @GetMapping("/api/payments")
    public List<Payment> getPayments() {
        return paymentRepository.findAll();
    }

    @PostMapping("/api/payments")
    public Payment makePayment(@RequestBody Map<String, Object> body) {
        Payment payment = new Payment();
        payment.setOrderId((String) body.get("orderId"));
        payment.setAmount(Double.parseDouble(body.get("amount").toString()));
        payment.setStatus("PAID");
        return paymentRepository.save(payment);
    }
}