package com.yididiya.order_service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
public class OrderController {

    private final OrderRepository orderRepository;

    @Autowired
    private ProductRepository productRepository;

    @Value("${instance.id}")
    private String instanceId;

    public OrderController(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    @GetMapping("/api/orders/ping")
    public String ping() { return "ORDERS OK - " + instanceId; }

    @GetMapping("/api/orders")
    public Map<String, Object> getOrders() {
        return Map.of("instance", instanceId, "orders", orderRepository.findAll());
    }

    @PostMapping("/api/orders")
    public Order createOrder(@RequestBody Map<String, Object> body) {
        Order order = new Order();
        order.setProduct((String) body.get("product"));
        order.setQuantity((Integer) body.get("quantity"));
        order.setStatus("CREATED");
        order.setHandledBy(instanceId);
        return orderRepository.save(order);
    }

    @PostMapping("/api/products")
    public Product createProduct(@RequestBody Map<String, Object> body) {
        Product p = new Product();
        p.setName((String) body.get("name"));
        p.setQuantity((Integer) body.get("quantity"));
        return productRepository.save(p);
    }

    @GetMapping("/api/products")
    public List<Product> getProducts() {
        return productRepository.findAll();
    }

    @GetMapping("/api/products/{id}")
    public Product getProduct(@PathVariable Long id) {
        return productRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    @PatchMapping("/api/products/{id}/quantity")
    public Product updateQuantity(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        Product p = productRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Product not found"));
        p.setQuantity((Integer) body.get("quantity"));
        return productRepository.save(p);
    }
}